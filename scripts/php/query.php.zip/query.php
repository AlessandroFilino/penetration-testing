<?php
require_once "config.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["query"]) && !empty($_POST["query"])) {
        $query = $_POST["query"];

        $con = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
        $result = $con->query($query);

        if ($result) {
            if ($result->num_rows > 0) {
                echo "<h2>Query Result</h2>";
                echo "<table border='1'>";
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    foreach ($row as $value) {
                        echo "<td>" . $value . "</td>";
                    }
                    echo "</tr>";
                }
                echo "</table>";
            } else {
                echo "Query executed successfully but no results found.";
            }
        } else {
            echo "Error executing query: " . $con->error;
        }

        $con->close();
    } else {
        echo "Please enter a query.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Execute Query</title>
</head>
<body>
    <h2>Enter Query</h2>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <textarea name="query" rows="4" cols="50"></textarea><br><br>
        <input type="submit" value="Execute">
    </form>
</body>
</html>
